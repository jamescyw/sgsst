# @intranet/sdk

Puente entre el **shell de la Intranet** y las **apps embebidas** en iframe.
Sin dependencias, agnóstico de framework (React, Vue, Angular, JS plano, legacy).

**Versión: `0.2.0`** · Protocolo: `v1` · En tiempo de ejecución: `SDK_VERSION` y `PROTOCOL_VERSION`.

| Funcionalidad | API |
|---|---|
| Validar que corre en el iframe del shell y origen correcto | `init()` (rechaza con `NOT_EMBEDDED` / `ORIGIN_NOT_ALLOWED`) |
| Compartir JWT de la app | `getToken()`, `onTokenChange()` |
| Ruta actual y cambios (bidireccional) | `getRoute()`, `setRoute()`, `onRouteChange()`, `syncHistory()` |
| Inventario de dependencias | `init({ dependencies })` → visible en el admin de apps |
| Extras | `getUser()`, `getTheme()`/`onThemeChange()`, `onSessionLost()`, `toast()` |

## Instalación

**Con bundler (npm):**

```ts
import { init, syncHistory } from '@intranet/sdk'
import pkg from '../package.json'

const intranet = await init({
  dependencies: pkg.dependencies,
  dev: import.meta.env.DEV, // acepta http://localhost:5173 como shell
})
syncHistory(intranet) // React Router, Vue Router, Angular... (History API)
```

**Sin bundler (`<script>`):** el shell sirve la versión IIFE, que expone `window.IntranetSDK`.

```html
<script src="https://intranet-v2.crepesywaffles.com/sdk/v1/intranet-sdk.js"></script>
<script>
  IntranetSDK.init({ dependencies: { jquery: '3.7.1' } }).then((intranet) => {
    IntranetSDK.syncHistory(intranet, { mode: 'hash' })
  })
</script>
```

## Opciones de `init`

| Opción | Por defecto | Descripción |
|---|---|---|
| `allowedShellOrigins` | `['https://intranet-v2.crepesywaffles.com']` | Orígenes del shell aceptados. |
| `dev` | `false` | Agrega `http://localhost:5173` y `http://127.0.0.1:5173`. |
| `timeoutMs` | `10000` | Espera del saludo y de cada petición de token. |
| `dependencies` | `{}` | `{ nombre: versión }` (máx. 200). |
| `onOutside` | `'throw'` | `'redirect'` lleva a `<shell>/app/<appSlug><ruta>` si se abre fuera del iframe. |
| `appSlug` | — | `path_slug` de la app; necesario para `onOutside: 'redirect'`. |
| `basePath` | `''` | Prefijo de la app en su servidor (p. ej. `/miapp`). |
| `captureErrors` | `true` | Reporta a la Intranet los errores no capturados de la app (ver [Registro de errores](#registro-de-errores)). |

## Token

```ts
const res = await fetch('/api/pedidos', {
  headers: { Authorization: `Bearer ${await intranet.getToken()}` },
})
```

- El token es de vida corta (10 min) y válido solo para esta app (`aud = path_slug`).
  El shell lo renueva solo; `getToken()` siempre devuelve uno vigente.
- Guárdalo **solo en memoria**. No uses cookies: dentro del iframe son de terceros.
- **El backend de la app debe validarlo** antes de confiar en él:

  ```http
  GET https://intranet-v2.crepesywaffles.com/api/auth/verify
  Authorization: Bearer <token>
  ```

  Responde `200 { app, expires_at, usuario }` si la sesión sigue viva y el
  usuario tiene acceso a la app; `401` en otro caso.

## Rutas

La URL del shell es `/app/<slug><ruta>`. El iframe siempre carga `url_app`; la ruta
viaja por mensajes. Con `syncHistory` no hay que hacer nada más:

- **Deep link:** en la primera carga (`intranet.initial === true`) la app va a
  `intranet.getRoute()`.
- La app navega → el shell actualiza su URL (replace, sin recargar el iframe).
- Atrás/adelante o clic en el menú del shell → la app recibe la ruta, se aplica
  con `replaceState` y se dispara `popstate` para que el router la renderice.

| `mode` | Para |
|---|---|
| `'path'` (por defecto) | SPA con History API (React Router, Vue Router, Angular `PathLocationStrategy`) |
| `'hash'` | SPA con rutas `#/...` (Angular `HashLocationStrategy`, routers en modo hash) |
| `'mpa'` | Apps multipágina: las navegaciones pedidas por el shell hacen `location.replace` |

Integración manual (si prefieres no usar `syncHistory`):

```ts
if (intranet.initial && intranet.getRoute() !== '/') router.replace(intranet.getRoute())
intranet.onRouteChange((path) => router.replace(path))
router.afterEach((to) => intranet.setRoute(to.fullPath))
```

Regla del historial: el del iframe se comparte con la ventana del shell, así que
quien **recibe** un cambio de ruta lo aplica con *replace*; solo quien lo origina
agrega una entrada.

Las rutas deben empezar por `/`; se rechazan URLs absolutas, `//`, segmentos `..` y `\`.

## Errores

`init` y `getToken` rechazan con `IntranetSDKError` (`err.code`):
`NOT_EMBEDDED`, `ORIGIN_NOT_ALLOWED`, `HANDSHAKE_TIMEOUT`, `TOKEN_TIMEOUT`,
`SHELL_ERROR`, `SESSION_LOST`, `DESTROYED`, `INVALID_ARGUMENT`.

```ts
try {
  intranet = await init()
} catch (err) {
  if (err instanceof IntranetSDKError && err.code === 'NOT_EMBEDDED') {
    document.body.textContent = 'Abre esta aplicación desde la Intranet.'
  }
}
```

## Registro de errores

Desde la `0.2.0` el SDK envía al shell los errores de la app, y los administradores los ven en
**Administración → Logs → Errores** con el mensaje, el stack, la ruta, el usuario y la versión
del SDK.

- **Automático** (`captureErrors: true`, por defecto): escucha `error` y
  `unhandledrejection` en la ventana de la app. Los errores que ocurren antes de que el shell
  responda el saludo se guardan (hasta 10) y se envían al conectar.
- **Manual**: para errores que la app captura y maneja pero conviene registrar.

```ts
try {
  await guardarPedido()
} catch (err) {
  intranet.toast('error', 'No se pudo guardar el pedido.')
  intranet.reportError(err, { path: '/pedidos/12' }) // path es opcional: por defecto, la ruta actual
}
```

Los errores que lanzan tus callbacks de `onThemeChange`, `onRouteChange`, etc. también se
reportan. Para no inundar al shell, el mismo error no se repite en 5 s y se envían como
máximo 10 por minuto. Un shell anterior a esta versión ignora estos mensajes sin fallar.

## Seguridad

La validación de iframe y origen del SDK es **protección del lado del navegador**:
cualquiera puede quitarla. La seguridad real de cada app es:

1. Cabecera `Content-Security-Policy: frame-ancestors https://intranet-v2.crepesywaffles.com`
   en el servidor de la app (ver `.deploy/server/Caddyfile`, snippet `(app)`).
2. Validar el token en su backend con `/api/auth/verify`.

## Protocolo

Mensajes `postMessage` versionados (`{ ns: 'intranet', v: 1, type, id?, replyTo?, payload }`).
El contrato está en [`src/protocol.ts`](src/protocol.ts) y lo comparte el shell.

## Desarrollo

```sh
npm install
npm test           # vitest
npm run coverage   # umbral 80 %
npm run build      # dist/: index.mjs, index.cjs, intranet-sdk.iife.js, *.d.ts
```

## Empaquetar para otras apps

El SDK no está en un registro npm: se distribuye como archivo.

```sh
cd sdk
npm run release              # pruebas + build + empaquetado
npm run release -- --sin-tests

# o desde frontend/:
npm run sdk:release
```

Deja en `sdk/release/` (no se sube al repo):

| Archivo | Uso |
|---|---|
| `intranet-sdk-<versión>.tgz` | Apps con bundler: copiarlo a `vendor/` de la app y `npm install ./vendor/intranet-sdk-<versión>.tgz` |
| `intranet-sdk-<versión>.iife.js` | Apps sin bundler: servirlo como estático y cargarlo con `<script>` (o usar `/sdk/v1/intranet-sdk.js` del shell) |
| `INSTALAR.md` | Instrucciones para el equipo de la app |

Para sacar una versión nueva, antes de correr `npm run release`:

1. Sube `version` en `sdk/package.json`.
2. Actualiza la versión escrita a mano en este README (línea **Versión** del inicio) y en el
   `README.md` de la raíz (sección "SDK de integración").
